import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		System.out.println("Calculate the Perimeter of a Circle   ");
		System.out.println("");
		double r;
		System.out.print("r=");
		Scanner input = new Scanner (System.in);
		r = input.nextDouble();
		System.out.println("");
		System.out.println("Perimeter = "+3.1415*2*r);
	}
}