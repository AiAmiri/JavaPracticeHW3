import java.util.Scanner;
public class FarenhitToC {
	public static void main(String[] args) {
	 System.out.println("Converter from Fahrenhite to Celsius ");
	 Scanner input = new Scanner(System.in);
	 System.out.print(" enter Temperature in fahrenhit = ");
	 double f =input.nextDouble();
	 System.out.print("It is equal to = " +(5.0/9)*(f-32) + " celsius");
	}
}