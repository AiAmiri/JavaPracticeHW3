import java.util.Scanner;
public class  SphereValume {
	public static void main(String[] args) {
	 System.out.println(" valume of sphare calculator");
	 Scanner input = new Scanner(System.in);
	 System.out.print(" enter radiuse value = ");
	 double r =input.nextDouble();
	 System.out.println("volume = "+ 4d/3*Math.PI*r*r*r);
	}
}