import java.util.Scanner;
public class CylinderValume {
	public static void main(String[] args) {
	 System.out.println("volume of cylinder calculator");
	 Scanner input=new Scanner(System.in);
	 System.out.print("enter r value =");
	 double r=input.nextDouble();
	 System.out.print("enter height value =");
	 double height=input.nextDouble();
	 System.out.print(" volume of cylinder ="+r*r*height*3.1415);
    }
}