import java.util.Scanner;
public class  FindRoot {
	public static void main(String[] args) {
	 System.out.println(" roots calculator for quadratic eqation");
	 System.out.println(" y=ax^2+bx+c ");
	 Scanner input = new Scanner(System.in);
	 System.out.print(" enter a value = ");
	 double a =input.nextDouble();
	 System.out.print(" enter b value = ");
	 double b =input.nextDouble();
	 System.out.print(" enter c value = ");
	 double c =input.nextDouble();
	 double delta=(b*b)-(4*a*c);
	 double r1=(-b+Math.sqrt(delta))/2d*a;
	 double r2=(-b-Math.sqrt(delta))/2d*a;
	 System.out.println("first root = " + r1);
	 System.out.println("second root = " + r2);
	}
}