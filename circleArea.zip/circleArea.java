import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		System.out.println("cmpute the area of circle");
		System.out.println("");
		double r;
		System.out.print("r=");
		Scanner input = new Scanner (System.in);
		r= input.nextDouble();
		
		System.out.println("Area =" + 3.1415*r*r);
	}
}