import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		System.out.println("Calculate the Area of a Triangle    ");
		double h;
		double b;
		System.out.println("");
		System.out.print("height=");
		Scanner input = new Scanner (System.in);
		h = input.nextDouble();
		System.out.print("base=");
		Scanner input1 = new Scanner (System.in);
		b = input.nextDouble();
		System.out.println("");
		System.out.println("Area = "+ h*b/2);
		
	}
}