import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		System.out.println("Calculator for the Volume of a Cylinder ");
		System.out.println("");
		System.out.print("r = ");
		double r;
		double h;
		Scanner input = new Scanner (System.in);
		r = input.nextDouble();
		System.out.print("height = ");
		Scanner input1 = new Scanner (System.in);
		h = input.nextDouble();
		System.out.println("");
		System.out.println("Volume = "+ r*r*h*3.1415);
	}
}