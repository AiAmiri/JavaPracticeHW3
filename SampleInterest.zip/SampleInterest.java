import java.util.Scanner;
public class SampleInterest {
	public static void main(String[] args) {
	 System.out.println(" sample interest calculator");
	 Scanner input = new Scanner(System.in);
	 System.out.print(" enter principal value = ");
	 double p =input.nextDouble();
	 System.out.print(" enter rate of interset value = ");
	 double r =input.nextDouble();
	 System.out.print(" enter time period = ");
	 double t =input.nextDouble();
	 System.out.print(" sample interest = "+ p*r*t/100);
	}
}