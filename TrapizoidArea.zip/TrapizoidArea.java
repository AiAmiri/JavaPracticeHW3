import java.util.Scanner;
public class  TrapizoidArea {
	public static void main(String[] args) {
	 System.out.println(" trapizoid area calculator");
	 Scanner input = new Scanner(System.in);
	 System.out.print(" enter a value = ");
	 double a =input.nextDouble();
	 System.out.print(" enter b value = ");
	 double b =input.nextDouble();
	 System.out.print(" enter height value = ");
	 double h =input.nextDouble();
	 System.out.println("area = "+0.5*(a+b)*h);
	}
}