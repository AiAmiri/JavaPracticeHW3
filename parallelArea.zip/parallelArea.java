import java.util.Scanner;
public class ParrallelArea {
	public static void main(String[] args) {
	 System.out.println("parralellelogram Area");
	 Scanner input = new Scanner(System.in);
	 System.out.print(" enter base value = ");
	 double base =input.nextDouble();
	 System.out.print(" enter height value = ");
	 double height=input.nextDouble();
	 System.out.print("  area = " + base*height);
	}
}