import java.util.Scanner;
public class  SphereArea {
	public static void main(String[] args) {
	 System.out.println(" surface area of sphare calculator");
	 Scanner input = new Scanner(System.in);
	 System.out.print(" enter radiuse value = ");
	 double r =input.nextDouble();
	 System.out.println("Area = "+ 4*Math.PI*r*r);
	}
}