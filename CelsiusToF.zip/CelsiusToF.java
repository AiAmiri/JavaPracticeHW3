import java.util.Scanner;
public class CelsiusToF {
	public static void main(String[] args) {
	 System.out.println("Converter from Celsius to Fahrenhite ");
	 Scanner input = new Scanner(System.in);
	 System.out.print(" enter Temperature in celsius = ");
	 double c =input.nextDouble();
	 System.out.print("It is equal to = " +(9d/5*c+32));
	}
}