import java.util.Scanner;
public class Main {
	public static void main(String[] args) {
		System.out.println("Calculator for  the Perimeter of a Rectangle ");
		System.out.println("");
		double a;
		double b;
		System.out.print("length = ");
		Scanner input = new Scanner (System.in);
		a = input.nextDouble();
		System.out.print("width = ");
		Scanner input1 = new Scanner (System.in);
		b = input.nextDouble();
		System.out.println("Perimeter = "+(a+b)*2);
																						
		}
}