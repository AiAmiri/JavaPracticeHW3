import java.util.Scanner;
public class  TrianglePerimeter {
	public static void main(String[] args) {
	 System.out.println(" perimeter of triangle calculator");
	 Scanner input = new Scanner(System.in);
	 System.out.print(" enter a value = ");
	 double a =input.nextDouble();
	 System.out.print(" enter b value = ");
	 double b =input.nextDouble();
	 System.out.print(" enter c value = ");
	 double c =input.nextDouble();
	 System.out.println("area = "+ (a+b+c) );
	}
}