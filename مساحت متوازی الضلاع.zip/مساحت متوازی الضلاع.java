import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		System.out.println("Calculator for the Area of a Parallelogram");
		System.out.println("");
		System.out.print("base = ");
		double b;
		double h;
		Scanner input = new Scanner (System.in);
		b = input.nextDouble();
		System.out.print("height = ");
		Scanner input1 = new Scanner (System.in);
		h = input.nextDouble();
		System.out.println("");
		System.out.println("Area = "+b*h );
	}
}