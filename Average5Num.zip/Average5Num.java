import java.util.Scanner;
public class  Average5Num {
	public static void main(String[] args) {
	 Scanner input = new Scanner(System.in);
	 System.out.println(" averege of 5 number");
	 System.out.print(" enter first num = ");
	 double a =input.nextDouble();
	 System.out.print(" enter second num = ");
	 double b =input.nextDouble();
	 System.out.print(" enter thirth num = ");
	 double c =input.nextDouble();
	 System.out.print(" enter fourth num = ");
	 double d =input.nextDouble();
	 System.out.print(" enter fifth num = ");
	 double e =input.nextDouble();
	 System.out.println("Average = "+(a+b+c+d+e)/5 );
	}
}