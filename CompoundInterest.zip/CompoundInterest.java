import java.util.Scanner;
public class  CompoundInterest {
	public static void main(String[] args) {
	 System.out.println(" Compound interest calculator");
	 Scanner input = new Scanner(System.in);
	 System.out.print(" enter principal value = ");
	 double p =input.nextDouble();
	 System.out.print(" enter rate of interset value = ");
	 double r =input.nextDouble();
	 System.out.print(" enter time period = ");
	 double t =input.nextDouble();
	 System.out.print(" enter number of time interest = ");
	 double n =input.nextDouble();
	 double cI=p*Math.pow(1+r/n,n*t);
	 System.out.println("compound interest = "+ cI);
	}
}